You need to fully extract the zip file to a folder on your computer.

The VBA code uses specific file paths and running the tool from within 
the zip will result in an error.

The code only runs on machines running Windows.